'use strict'

ons.bootstrap();

ons.ready(function(){
//menu.openMenu();
})

var app = angular.module('fitenesse', ['onsen']);
app.controller('appController',function($scope){


});