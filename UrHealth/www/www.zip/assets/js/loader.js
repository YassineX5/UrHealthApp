document.addEventListener('init',function(e){

console.log(e.target.name);
    if(e.target.name == "login_page") alert("login");

     

    
},false);